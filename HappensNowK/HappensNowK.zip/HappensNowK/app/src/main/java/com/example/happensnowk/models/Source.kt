package com.example.happensnowk.models

data class Source(
    val id: Any,
    val name: String
)