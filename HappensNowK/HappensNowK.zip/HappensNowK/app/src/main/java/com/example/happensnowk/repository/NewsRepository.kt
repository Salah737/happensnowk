package com.example.happensnowk.repository

import com.example.happensnowk.api.RetrofitInstance
import com.example.happensnowk.db.ArticleDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class NewsRepository (
    val db:ArticleDatabase
        ){
    suspend fun getBreakingNews(countryCode:String,pageNumber:Int)=
        RetrofitInstance.api.getBreakingNews(countryCode,pageNumber)
    suspend fun searchNews(searchQuery:String ,pageNumber: Int)=
        RetrofitInstance.api.searchForNews(searchQuery,pageNumber)
}