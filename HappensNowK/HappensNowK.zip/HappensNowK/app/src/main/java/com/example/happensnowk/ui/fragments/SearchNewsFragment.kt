package com.example.happensnowk.ui.fragments

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.ProgressBar
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Observer
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.happensnowk.R
import com.example.happensnowk.adapters.NewsAdapter
import com.example.happensnowk.models.Article
import com.example.happensnowk.ui.NewsViewModel
import com.example.happensnowk.util.Constants.Companion.SEARCH_NEWS_TIME_DELAY
import com.example.happensnowk.util.Resource
import kotlinx.coroutines.Job
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class SearchNewsFragment : Fragment(R.layout.fragment_search_news) {
    //    lateinit var viewModel:NewsViewModel
    val viewModel: NewsViewModel by activityViewModels()
    lateinit var newsAdapter: NewsAdapter
    lateinit var rvBreakingNews: RecyclerView
    lateinit var paginationProgressBar: ProgressBar
    lateinit var searchEditText: EditText
    val TAG = "SearchNewsFragment"
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
//        viewModel=(activity as NewsActivity).viewModel
        rvBreakingNews = view.findViewById(R.id.rvSearchNews)
        paginationProgressBar = view.findViewById(R.id.paginationProgressBar)
        searchEditText =view.findViewById(R.id.etSearch)
        initRecyclerView()
        newsAdapter.setOnItemClickListener (object :(Article)->Unit{
            override fun invoke(article: Article) {
                val bundle =Bundle().apply {
                    putSerializable("article",article)
                }
                findNavController().navigate(
                    R.id.action_breakingNewsFragment_to_articleFragment_preview,
                    bundle
                )
            }


        })

        var job: Job?=null
        searchEditText.addTextChangedListener { editable->
            job?.cancel()
            job= MainScope().launch {
                delay(SEARCH_NEWS_TIME_DELAY)
                editable?.let {
                    if(editable.toString().isNotEmpty()){
                        viewModel.searchNews(editable.toString())

                    }
                }

            }
        }


        viewModel.searchNews.observe(viewLifecycleOwner, Observer { response ->
            when (response) {
                is Resource.Error -> {
                    response.massege?.let { message ->
                        Log.e(TAG, "An error occured:$message")
                    }

                }
                is Resource.Loading -> {
                    initRecyclerView()
                    showProgressBar()
                }
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { newsResponse ->
                        newsAdapter.differ.submitList(newsResponse.articles)
                    }
                }
            }

        })


    }

    private fun hideProgressBar() {

        paginationProgressBar.visibility = View.INVISIBLE
    }

    private fun showProgressBar() {
        paginationProgressBar.visibility = View.VISIBLE

    }

    private fun initRecyclerView() {
        newsAdapter = NewsAdapter()
        rvBreakingNews.apply {
            adapter = newsAdapter
            layoutManager = LinearLayoutManager(activity)

        }

    }

}