package com.example.happensnowk.ui.fragments

import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.happensnowk.R
import com.example.happensnowk.adapters.NewsAdapter
import com.example.happensnowk.models.Article
import com.example.happensnowk.ui.NewsViewModel

class SavedNewsFragment:Fragment(R.layout.fragment_saved_news) {
//    lateinit var viewModel:NewsViewModel
     val viewModel:NewsViewModel by activityViewModels()
    lateinit var newsAdapter:NewsAdapter
    lateinit var rvBreakingNews: RecyclerView
    lateinit var paginationProgressBar : ProgressBar
    val TAG="SavedNewsFragment"
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
//        viewModel=(activity as NewsActivity).viewModel
        initRecyclerView()



    newsAdapter.setOnItemClickListener (object :(Article)->Unit{
        override fun invoke(article: Article) {
            val bundle =Bundle().apply {
                putSerializable("article",article)
            }
            findNavController().navigate(
                R.id.action_savedNewsFragment_to_articleFragment_preview,
                bundle
            )
        }


    })



    }
    private fun hideProgressBar() {

        paginationProgressBar.visibility= View.INVISIBLE
    }
    private fun showProgressBar(){
        paginationProgressBar.visibility=View.VISIBLE

    }

    private fun initRecyclerView(){
        newsAdapter = NewsAdapter()
        rvBreakingNews.apply {
            adapter= newsAdapter
            layoutManager= LinearLayoutManager(activity)

        }

    }

}