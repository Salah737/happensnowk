package com.example.happensnowk.util

class Constants {
    companion object{
        const val API_KEY:String="60d22fdb9073489f86e8856080aaf320"
        const val BASE_URL:String ="https://newsapi.org/"
        const val SEARCH_NEWS_TIME_DELAY=500L
    }
}