package com.example.happensnowk.ui.fragments

import android.os.Bundle
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.fragment.app.Fragment
import androidx.navigation.NavArgs
import androidx.navigation.NavArgument
import androidx.navigation.fragment.navArgs
import com.example.happensnowk.R
import com.example.happensnowk.models.Article
import com.example.happensnowk.ui.NewsActivity
import com.example.happensnowk.ui.NewsViewModel

class ArticleFragment:Fragment(R.layout.fragment_artical_preview) {
    lateinit var viewModel:NewsViewModel
    lateinit var webView:WebView
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel=(activity as NewsActivity).viewModel
//        webView=view.findViewById(R.id.webView)
//    val article = arguments?.getBundle("article")as Article
//    webView.apply {
//        webViewClient = WebViewClient()
//        loadUrl(article.url)
//    }
    }

}